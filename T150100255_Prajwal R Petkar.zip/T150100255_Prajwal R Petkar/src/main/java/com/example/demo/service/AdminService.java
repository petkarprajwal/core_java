package com.example.demo.service;

import com.example.demo.entity.MallAdmin;
import com.example.demo.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminService {

    private final AdminRepository adminRepository;

    @Autowired
    public AdminService(AdminRepository adminRepository) {
        this.adminRepository = adminRepository;
    }

    // CREATE
    public MallAdmin addAdmin(MallAdmin admin) {
        return adminRepository.save(admin);
    }

    // READ ALL
    public List<MallAdmin> getAllAdmins() {
        return adminRepository.findAll();
    }

    // READ ONE
    public MallAdmin getAdminById(Integer id) {
        return adminRepository.findById(id).orElse(null);
    }

    // UPDATE
    public MallAdmin updateAdmin(Integer id, MallAdmin updatedAdmin) {
        return adminRepository.findById(id).map(existingAdmin -> {
            if (updatedAdmin.getName() != null)
                existingAdmin.setName(updatedAdmin.getName());
            if (updatedAdmin.getPhoneNo() != null)
                existingAdmin.setPhoneNo(updatedAdmin.getPhoneNo());
            if (updatedAdmin.getPassword() != null)
                existingAdmin.setPassword(updatedAdmin.getPassword());
            return adminRepository.save(existingAdmin);
        }).orElse(null);
    }

    // DELETE
    public void deleteAdmin(Integer id) {
        adminRepository.deleteById(id);
    }
}
