package com.example.demo.controller;

import com.example.demo.entity.MallAdmin;
import com.example.demo.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admins")
public class AdminController {

    @Autowired
    private AdminService adminService;

    // CREATE
    @PostMapping("/create")
    public ResponseEntity<MallAdmin> createAdmin(@RequestBody MallAdmin admin) {
        MallAdmin savedAdmin = adminService.addAdmin(admin);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedAdmin);
    }

    @GetMapping("/all")
    public ResponseEntity<List<MallAdmin>> getAllAdmins() {
        List<MallAdmin> admins = adminService.getAllAdmins();
        return ResponseEntity.ok(admins);
    }

    // READ ONE
    @GetMapping("/get/{id}")
    public ResponseEntity<MallAdmin> getAdminById(@PathVariable Integer id) {
        MallAdmin admin = adminService.getAdminById(id);
        return ResponseEntity.ok(admin);
    }


    // UPDATE
    @PutMapping("/update/{id}")
    public ResponseEntity<MallAdmin> updateAdmin(@PathVariable Integer id, @RequestBody MallAdmin updatedAdmin) {
        MallAdmin admin = adminService.updateAdmin(id, updatedAdmin);
        if (admin != null) {
            return ResponseEntity.ok(admin);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    // DELETE
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteAdmin(@PathVariable Integer id) {
        MallAdmin admin = adminService.getAdminById(id);
        if (admin != null) {
            adminService.deleteAdmin(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }
}
