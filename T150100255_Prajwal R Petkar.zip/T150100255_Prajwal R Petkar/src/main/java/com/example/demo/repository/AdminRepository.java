package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.entity.MallAdmin;

public interface AdminRepository extends JpaRepository<MallAdmin, Integer> {
    // You can add custom query methods here if needed
}
