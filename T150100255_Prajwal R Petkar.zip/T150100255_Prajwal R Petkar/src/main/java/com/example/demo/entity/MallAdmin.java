package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "mall_admin") // Optional: explicit table name
public class MallAdmin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment primary key
    private Integer id; // Use Integer so it can be null before persistence

    @Column(nullable = false)
    private String name;

    @Column(name = "phone_no", nullable = false, unique = true, length = 20)
    private String phoneNo;

    @Column(nullable = false)
    private String password;

    // Required by JPA (should be at least protected)
    protected MallAdmin() {}

    public MallAdmin(String name, String phoneNo, String password) {
        this.name = name;
        this.phoneNo = phoneNo;
        this.password = password;
    }

    // Getters and setters
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getPhoneNo() {
        return phoneNo;
    }
    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    // Optional helpers (uncomment if needed)
    // @Override
    // public String toString() {
    //     return "MallAdmin{id=" + id + ", name='" + name + "', phoneNo='" + phoneNo + "'}";
    // }
}